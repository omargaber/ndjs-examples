exports.port = process.env.PORT || 4000
exports.origin = process.env.ORIGIN || `http://localhost:${exports.port}`
